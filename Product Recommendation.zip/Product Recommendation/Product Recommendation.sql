

-- What customers are buying
select * from Orders_data
select * from Products_data
select * from sales_Jan
select * from Purchase_Data
SELECT * FROM tbl_users;
WITH ORDERS as
(
	SELECT O.order_id, O.customer_id, O.Product_ID, P.product_name, P.category 
	FROM Orders_data o
	INNER JOIN products_data P
	ON O.product_id=P.product_id
),
Similar_Customers as 
(
	SELECT O1.customer_id as target_customer, O1.Product_ID, O1.product_name, O1.category, O2.customer_id as Similar_customer
	FROM ORDERS O1
	JOIN ORDERS O2
	ON O1.product_id=O2.product_id
	AND
	O1.customer_id<>O2.customer_id
	WHERE 
	--O1.customer_id='C_008'
	--AND 
	O1.product_name='Men''s T-Shirt'
),
Recommendation as (

	Select DISTINCT S.target_customer, Rec_O.product_name, Rec_o.category
	FROM ORDERS Rec_O
	INNER JOIN Similar_Customers S
	ON Rec_O.customer_id=S.Similar_customer
	WHERE Rec_O.product_name NOT IN (Select product_name from ORDERS
	WHERE customer_id=target_customer)
	)

Select * from Recommendation
Order By target_customer, product_name;



--Q1: List all products and show how many times each has been ordered. Is there any product that has never been ordered.
select p.product_name,count(o.order_id) as total_orders
from products_data p left join 
orders_data o 
on p.product_id=o.product_id
group by product_name;
--Q2: Sales teams use this to identify loyal customers or potential for upselling. Get a list of customers who placed more than one order. Show customer name and total orders placed
select o.customer_id,u.first_name,u.last_name,count(o.order_id) as total_order_placed
from orders_data o
LEFT JOIN
tbl_users u
on o.customer_id=u.cusomter_id
group by customer_id,u.first_name,u.last_name
having count(order_id)>1;
--Q3: Identify order IDs that exist in tbl_Orders but not in tbl_Sales [Without using Join]
;
select order_id from orders_data
EXCEPT
select New_OrderID from sales_Jan